
# Program 1: ASP.NET College Website

## Description
A simple ASP.NET Web Forms application that displays college information.

## Pages
- Home (Default.aspx)
- About (About.aspx)
- Courses (Courses.aspx)
- Contact (Contact.aspx)

## How to Run
1. Open the project in Visual Studio.
2. Set Default.aspx as the start page.
3. Press F5 to run the application.
