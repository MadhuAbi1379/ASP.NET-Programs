
<%@ Page Language="C#" AutoEventWireup="true" %>
<!DOCTYPE html>
<html>
<head>
    <title>Courses</title>
</head>
<body>
    <h2>Courses Offered</h2>
    <ul>
        <li>B.Sc Computer Science</li>
        <li>B.Com</li>
        <li>B.A English</li>
    </ul>
</body>
</html>
