
<%@ Page Language="C#" AutoEventWireup="true" %>
<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
</head>
<body>
    <h2>About Our College</h2>
    <p>We are a leading institution offering quality education.</p>
</body>
</html>
