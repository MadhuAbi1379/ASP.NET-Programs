
<%@ Page Language="C#" AutoEventWireup="true" %>
<!DOCTYPE html>
<html>
<head>
    <title>Contact Us</title>
</head>
<body>
    <h2>Contact Information</h2>
    <p>Email: info@college.edu</p>
    <p>Phone: +1 234 567 890</p>
</body>
</html>
