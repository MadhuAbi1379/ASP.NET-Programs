
<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="CollegeWebsite.Default" %>
<!DOCTYPE html>
<html>
<head>
    <title>College Website</title>
</head>
<body>
    <h1>Welcome to Our College</h1>
    <nav>
        <a href='About.aspx'>About Us</a> |
        <a href='Courses.aspx'>Courses</a> |
        <a href='Contact.aspx'>Contact</a>
    </nav>
    <p>This is the home page of the college website.</p>
</body>
</html>
